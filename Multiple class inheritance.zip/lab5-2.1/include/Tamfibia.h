#ifndef TAMFIBIA_H
#define TAMFIBIA_H
#include "Tpojazd.h"
#include "Tlodz.h"
#include "Tsamochod.h"

class Tamfibia : public Tpojazd, public Tlodz, public Tsamochod
{
    public:
        Tamfibia();
        virtual ~Tamfibia();
        void Info();

    protected:

    private:
};

#endif // TAMFIBIA_H
