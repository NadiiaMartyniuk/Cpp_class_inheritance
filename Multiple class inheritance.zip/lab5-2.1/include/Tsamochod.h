#ifndef TSAMOCHOD_H
#define TSAMOCHOD_H
#include<string>

using namespace std;

class Tsamochod
{
    public:
        Tsamochod();
        Tsamochod(string m, float s, float p);
        virtual ~Tsamochod();
        void Info();
        void WczytajSmochod();


    protected:
        string marka;
        float max_szybkosc;
        float przebieg_samochodu;

    private:
};

#endif // TSAMOCHOD_H
