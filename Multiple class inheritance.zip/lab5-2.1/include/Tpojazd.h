#ifndef TPOJAZD_H
#define TPOJAZD_H
#include<string>

using namespace std;
class Tpojazd
{
    public:
        Tpojazd();
        Tpojazd(string t, int w, int l, int s);
        void Info();
        void WczytajPojazd();
        virtual ~Tpojazd();


    protected:
        string typ;
        int liczba_wagonow;
        int liczba_miejsc_do_lezania;
        int liczba_miejsc_do_siedzenia;


    private:
};

#endif // TPOJAZD_H
