#ifndef TLODZ_H
#define TLODZ_H


class Tlodz
{
    public:
        Tlodz();
        Tlodz(float m);
        virtual ~Tlodz();
        void Info();
        void WczytajLodz();

    protected:
        float moc_silnika;


    private:
};

#endif // TLODZ_H
