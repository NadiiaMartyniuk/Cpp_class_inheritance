#include <iostream>
#include "Tpojazd.h"
#include "Tamfibia.h"
#include "Tlodz.h"
#include "Tsamochod.h"
#include <string>
using namespace std;

int main()
{
    /*Tpojazd pojazd;
    pojazd.WczytajPojazd();
    pojazd.Info();

    cout<<endl;

    Tsamochod samochod;
    samochod.WczytajSmochod();
    samochod.Info();

    cout<<endl;

    Tlodz lodz;
    lodz.WczytajLodz();
    lodz.Info();*/

    Tamfibia amfibia;
    amfibia.Info();

    return 0;
}
