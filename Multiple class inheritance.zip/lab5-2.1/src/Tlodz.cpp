#include "Tlodz.h"
#include <iostream>
using namespace std;
Tlodz::Tlodz()
{
    cout<<"Konstruktor domyslny klasy Tlodz"<<endl;
    moc_silnika=50;
}

Tlodz::Tlodz(float m)
{
    cout<<"Konstruktor z parametrami klasy Tlodz"<<endl;
    moc_silnika=m;
}

Tlodz::~Tlodz()
{
    cout<<"Destruktor klasy Tlodz"<<endl;
}

void Tlodz::WczytajLodz(){
    cout<<"Moc silnika ";
    cin>>moc_silnika;
    if (moc_silnika<=0){
        cout<<"Moc silnika nie moze byc mniejsza lub rowna 0"<<endl;
        cout<<"Moc silnika zostala zamieniona na 1"<<endl;
        moc_silnika=1;
    }
}

void Tlodz::Info(){
    cout<<endl<<"Moc silnika = "<<moc_silnika<<endl;
}
