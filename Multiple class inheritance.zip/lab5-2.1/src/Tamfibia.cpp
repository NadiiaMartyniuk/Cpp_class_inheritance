#include "Tamfibia.h"
#include "Tpojazd.h"
#include "Tlodz.h"
#include "Tsamochod.h"
#include <iostream>
using namespace std;
Tamfibia::Tamfibia()
{
    cout<<"Konstruktor domyslny klasy Tamfibia"<<endl;
}
Tamfibia::~Tamfibia()
{
    cout<<"Destruktor domyslny klasy Tamfibia"<<endl;

}
void Tamfibia::Info()
{
    WczytajSmochod();
    WczytajPojazd();
    WczytajLodz();
    Tsamochod::Info();
    Tpojazd::Info();
    Tlodz::Info();
}
