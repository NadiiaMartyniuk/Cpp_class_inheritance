#include "Tsamochod.h"
#include<string>
#include <iostream>
using namespace std;
Tsamochod::Tsamochod()
{
    cout<<"Konstruktor domyslny klasy Tsamochod"<<endl;
    marka="Audi";
    max_szybkosc=210;
    przebieg_samochodu=10000;
}

Tsamochod::Tsamochod(string m, float s, float p){
    cout<<"Konstruktor z parametrami klasy Tsamochod"<<endl;
    marka=m;
    max_szybkosc=s;
    przebieg_samochodu=p;
}

Tsamochod::~Tsamochod()
{
    cout<<"Destruktor klasy Tsamochod"<<endl;
}

void Tsamochod::Info(){
    cout<<endl;
    cout<<"Marka "<<marka<<endl;
    cout<<"Maksymalna szybkosc = "<<max_szybkosc<<" km/h"<<endl;
    cout<<"Przebieg samochodu "<<przebieg_samochodu<<" km"<<endl;
}

void Tsamochod::WczytajSmochod(){
    cout<<"Marka ";
    cin>>marka;
    cout<<"Maksymalna szybkosc = ";
    cin>>max_szybkosc;
    if (max_szybkosc<=0){
        cout<<"Max szybkosc nie moze byc mniejsza lub rowna 0"<<endl;
        cout<<"Max szybkosc zostala zamieniona na 1"<<endl;
        max_szybkosc=1;
    }
    cout<<"Przebieg samochodu ";
    cin>>przebieg_samochodu;
    if (przebieg_samochodu<=0){
        cout<<"Przebieg samochodu nie moze byc mniejszy lub rowny 0"<<endl;
        cout<<"Przebieg samochodu zostal zamieniony na 1"<<endl;
        przebieg_samochodu=1;
    }

}
