#include "Tpojazd.h"
#include<string>
#include <iostream>
using namespace std;

Tpojazd::Tpojazd()
{
    cout<<"Konstruktor domyslny klasy Tpojazd"<<endl;
    typ="Pociag pasazerski";
    liczba_wagonow=120;
    liczba_miejsc_do_lezania=240;
    liczba_miejsc_do_siedzenia=360;
}

Tpojazd::~Tpojazd()
{
    cout<<"Destruktor klasy Tpojazd"<<endl;
}

Tpojazd::Tpojazd(string t, int w, int l, int s){
    cout<<"Konstruktor z parametrami klasy Tpojazd"<<endl;
    typ=t;
    liczba_wagonow=w;
    liczba_miejsc_do_lezania=l;
    liczba_miejsc_do_siedzenia=s;
}

void Tpojazd::WczytajPojazd(){
    cout<<"Typ pojazdu: ";
    cin>>typ;
    cout<<"Liczba wagonow ";
    cin>>liczba_wagonow;
     if (liczba_wagonow<1){
        cout<<"Liczba wachonow nie moze byc mniejsza 1"<<endl;
        cout<<"Liczba wachonow zostala zamieniona na 1"<<endl;
        liczba_wagonow=1;
    }
    cout<<"liczba miejsc do lezania ";
    cin>>liczba_miejsc_do_lezania;
    if (liczba_miejsc_do_lezania<1){
        cout<<"Liczba miejsc do lezania nie moze byc mniejsza 1"<<endl;
        cout<<"Liczba miejsc do lezania zostala zamieniona na 1"<<endl;
        liczba_miejsc_do_lezania=1;
    }
    cout<<"liczba miejsc do siedzenia ";
    cin>>liczba_miejsc_do_siedzenia;
    if (liczba_miejsc_do_siedzenia<1){
        cout<<"Liczba miejsc do siedzenia nie moze byc mniejsza 1"<<endl;
        cout<<"Liczba miejsc do siedzenia zostala zamieniona na 1"<<endl;
        liczba_miejsc_do_siedzenia=1;
    }
}

void Tpojazd::Info(){
    cout<<endl;
    cout<<"Typ pojazdu: "<<typ<<endl;
    cout<<"Liczba wagonow "<<liczba_wagonow<<endl;
    cout<<"liczba miejsc do lezania "<<liczba_miejsc_do_lezania<<endl;
    cout<<"liczba miejsc do siedzenia "<<liczba_miejsc_do_siedzenia<<endl;
}
