#include "Tpracownik.h"
#include "Tosoba.h"
#include <iostream>
Tpracownik::Tpracownik()
{
    cout<<"Konstruktor domyslny Tpracownik"<<endl;
    imie="Nadiia";
    nazwisko="Martyniuk";
    firma="SoftWare";
}

Tpracownik::Tpracownik(string i, string n, string f)
{
     cout<<"Konstruktor z parametrami Tpracownik"<<endl;
     imie=i;
     nazwisko=n;
     firma=f;
}

void Tpracownik::wczytaj_DaneFirmy()
{
    Tosoba::wczytaj();
    cout<<"Podaj nazwu firmy ";
    cin>>firma;
    cout<<"Podaj % premii ";
    cin>>premia;
    if ((premia>100)||(premia<0)){
        cout<<"Premia moze byc od 0 do 100%"<<endl<<"Wprowadzona liczba wychodzi z tego zakresu"<<endl<<"% premii zostal zamieniony na 0"<<endl;
        premia=0;
    }

}

void Tpracownik::wyswietl_DaneFirmy()
{
    Tosoba::wyswietl();
    cout<<"Firma: "<<firma<<", % premii w danej firmie = "<<premia<<"%"<<endl;
}

Tpracownik::~Tpracownik()
{
    cout<<"Destruktor Tpracownik. Objekt usunieto"<<endl;
}
