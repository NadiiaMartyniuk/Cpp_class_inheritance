#include "TpracownikUmyslowy.h"
#include "Tpracownik.h"
#include "Tosoba.h"
#include <iostream>
TpracownikUmyslowy::TpracownikUmyslowy()
{
    cout<<"Konstruktor z parametrami TpracownikUmyslowy"<<endl;
    imie="Nadiia";
    nazwisko="Martyniuk";
    firma="SoftWare";
    wynagrodzenie_mies=70;
    premia=30;
}

TpracownikUmyslowy::TpracownikUmyslowy(string i, string n, string f, float s, float p)
{
    cout<<"Konstruktor z parametrami TpracownikUmyslowy"<<endl;
    imie=i;
    nazwisko=n;
    firma=f;
    wynagrodzenie_mies=s;
    premia=p;
}

TpracownikUmyslowy::~TpracownikUmyslowy()
{
    cout<<"Destruktor TpracownikUmyslowy. Objekt usunieto"<<endl;
}

void TpracownikUmyslowy::wczytaj_Umyslowy()
{
    Tpracownik::wczytaj_DaneFirmy();
    cout<<"Wynagrodzenie miesieczne ";
    cin>>wynagrodzenie_mies;
    if (wynagrodzenie_mies<0){
        cout<<"Wynagrodzenie miesieczne nie moze byc liczba ujemna"<<endl;
        cout<<"Wynagrodzenie miesieczne zostalo zamienione na 0"<<endl;
        wynagrodzenie_mies=0;
    }

}

void TpracownikUmyslowy::wyswietl_Umyslowy()
{
    Tpracownik::wyswietl_DaneFirmy();
    cout<<"Wynagrodzenie miesienczne = "<<wynagrodzenie_mies<<" zlotych"<<endl;
    cout<<"Za miesiac otrzymal "<<PensiaUmyslowy()<<" zlotych"<<endl;
}

float TpracownikUmyslowy::PensiaUmyslowy(){
    return wynagrodzenie_mies+(wynagrodzenie_mies*premia);
}
