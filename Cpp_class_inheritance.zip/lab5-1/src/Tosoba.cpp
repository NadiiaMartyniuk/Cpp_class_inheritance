#include "Tosoba.h"
#include <iostream>
Tosoba::Tosoba()
{
    cout<<"Konstruktor domyslny Tosoba"<<endl;
    imie="Nadiia";
    nazwisko="Martyniuk";
}
Tosoba::Tosoba(string i, string n)
{
     cout<<"Konstruktor z parametrami Tosoba"<<endl;
     imie=i;
     nazwisko=n;
}
Tosoba::~Tosoba()
{
     cout<<"Destruktor Tosoba. Odjekt usunieto"<<endl;
}

void Tosoba::wczytaj(){
    cout<<"Podaj imie ";
    cin>>imie;
    cout<<"Podaj nazwisko ";
    cin>>nazwisko;
}

void Tosoba::wyswietl(){
    cout<<imie<<" "<<nazwisko<<endl;
}
