#include "TpracownikFizyczny.h"
#include "Tpracownik.h"
#include "Tosoba.h"
#include <iostream>
TpracownikFizyczny::TpracownikFizyczny()
{
    cout<<"Konstruktor domyslny TpracownikFizyczny"<<endl;
    imie="Nadiia";
    nazwisko="Martyniuk";
    firma="SoftWare";
    stawkaGod=50;
    iloscGod=100;
    premia=25;
}

TpracownikFizyczny::TpracownikFizyczny(string i, string n, string f, float s, int g, float p)
{
    cout<<"Konstruktor z parametrami TpracownikFizyczny"<<endl;
    imie=i;
    nazwisko=n;
    firma=f;
    stawkaGod=s;
    iloscGod=g;
    premia=p;
}

TpracownikFizyczny::~TpracownikFizyczny()
{
    cout<<"Destruktor TpracownikFizyczny. Objekt usunieto"<<endl;
}

void TpracownikFizyczny::wczytaj_Fizyczny()
{
    Tpracownik::wczytaj_DaneFirmy();
    cout<<"Stawka za godzine ";
    cin>>stawkaGod;
    if (stawkaGod<0){
        cout<<"Stawka za godzine nie moze byc liczba ujemna"<<endl;
        cout<<"Stawka za godzine zostala zamieniona na 0"<<endl;
        stawkaGod=0;
    }
    cout<<"Ilosc godzin ";
    cin>>iloscGod;
    if (iloscGod<0){
        cout<<"Czas nie moze byc liczba ujemna"<<endl;
        cout<<"Liczba godzin zostala zamieniona na 0"<<endl;
        iloscGod=0;
    }

}

void TpracownikFizyczny::wyswietl_Fizyczny()
{
    Tpracownik::wyswietl_DaneFirmy();
    cout<<"Stawka za godzine = "<<stawkaGod<<endl;
    cout<<"Za miesiac otrzymal "<<PensiaFizyczny()<<" zlotych"<<endl;
}

float TpracownikFizyczny::PensiaFizyczny(){
    return (iloscGod*stawkaGod)+(iloscGod*stawkaGod*premia);
}
