#include "Tstudent.h"
#include <iostream>
Tstudent::Tstudent()
{
    cout<<"Konstruktor domyslny clasy Tstudent"<<endl;
    imie="Nadiia";
    nazwisko="Martyniuk";
    uczelnia="Politechnika";
    liczba_ocen=3;
    oceny = new float[liczba_ocen];
    for (int i=0; i<liczba_ocen; i++){
        oceny[i]=3;
    }

}

Tstudent::Tstudent(string i, string n, string u, int lo)
{
    cout<<"Konstruktor z parametrem clasy Tstudent"<<endl;
    imie=i;
    nazwisko=n;
    uczelnia=u;
    liczba_ocen=lo;
    oceny = new float[liczba_ocen];
    wczytajOceny();
}

Tstudent::~Tstudent()
{
    cout<<"Destruktor Tstudent. Objekt usunieto"<<endl;
}

void Tstudent::wczytaj(){
    Tosoba::wczytaj();
    cout<<"Podaj nazwu uczelni ";
    cin>>uczelnia;
}

void Tstudent::wyswietl(){
    Tosoba::wyswietl();
    cout<<"Uczelnia: "<<uczelnia<<endl;
}
void Tstudent::wczytajOceny(){
    for (int i=0; i<liczba_ocen; i++){
        cout<<"Podaj "<<i+1<<" ocenu ";
        cin>>oceny[i];
        if ((oceny[i]>5)||(oceny[i]<2)){
            cout<<"Wprowadzilesz zly dane, poniewaz ocena moze byc wylacznie z zakresu od 2 do 5"<<endl;
            cout<<"Ocena zostala zamieniona na 2"<<endl;
            oceny[i]=2;
        }
    }
}
float Tstudent::Srednia(){
    float sum;
    for (int i=0; i<liczba_ocen; i++){
        sum+= oceny[i];
    }
    cout<<"Srednia = "<<sum/liczba_ocen;
    return sum/liczba_ocen;
}
bool Tstudent::CzyZaliczyl(){
    for (int i=0; i<liczba_ocen; i++){
        if (oceny[i]<3){
            cout<<endl<<"Nie zaliczyl "<<endl;
            return 0;
        }
    }
    cout<<endl<<"Zaliczyl"<<endl;
    return 1;
}
