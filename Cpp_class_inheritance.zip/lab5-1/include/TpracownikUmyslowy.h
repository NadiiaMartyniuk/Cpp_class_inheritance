#ifndef TPRACOWNIKUMYSLOWY_H
#define TPRACOWNIKUMYSLOWY_H
#include "Tpracownik.h"


class TpracownikUmyslowy : public Tpracownik
{
    public:
        TpracownikUmyslowy();
        virtual ~TpracownikUmyslowy();
        TpracownikUmyslowy(string i, string n, string f, float s, float p);
        void wczytaj_Umyslowy();
        void wyswietl_Umyslowy();
        float PensiaUmyslowy();

    protected:
       float wynagrodzenie_mies;
    private:
};

#endif // TPRACOWNIKUMYSLOWY_H
