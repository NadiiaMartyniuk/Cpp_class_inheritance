#ifndef TPRACOWNIK_H
#define TPRACOWNIK_H
#include<string>
#include "Tosoba.h"


class Tpracownik : public Tosoba
{
    public:
        Tpracownik();
        Tpracownik(string i, string n, string f);
        virtual ~Tpracownik();
        void wczytaj_DaneFirmy();
        void wyswietl_DaneFirmy();

    protected:
        string firma;
        float premia;



    private:
};

#endif // TPRACOWNIK_H
