#ifndef TPRACOWNIKFIZYCZNY_H
#define TPRACOWNIKFIZYCZNY_H
#include "Tpracownik.h"


class TpracownikFizyczny : public Tpracownik
{
    public:
        TpracownikFizyczny();
        virtual ~TpracownikFizyczny();
        TpracownikFizyczny(string i, string n, string f, float s, int g, float p);
        void wczytaj_Fizyczny();
        void wyswietl_Fizyczny();
        float PensiaFizyczny();

    protected:
        float stawkaGod;
        int iloscGod;

    private:
};

#endif // TPRACOWNIKFIZYCZNY_H
