#ifndef TSTUDENT_H
#define TSTUDENT_H
#include "Tosoba.h"
#include<string>

class Tstudent : public Tosoba
{
    public:
        Tstudent();
        Tstudent(string i, string n, string u, int lo);
        void wyswietl(); //przeslananie metod
        void wczytaj(); //przeslananie metod
        void wczytajOceny();
        float Srednia();
        bool CzyZaliczyl();

        virtual ~Tstudent();

    protected:
         string uczelnia;
         float* oceny;
         int liczba_ocen;

    private:
};

#endif // TSTUDENT_H
