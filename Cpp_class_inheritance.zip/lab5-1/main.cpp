#include <iostream>
#include "Tosoba.h"
#include "Tstudent.h"
#include "Tstudent.h"
#include "TpracownikFizyczny.h"
#include "TpracownikUmyslowy.h"

using namespace std;

int main()
{
    Tstudent student;
    student.wczytaj();
    student.wczytajOceny();
    student.wyswietl();
    student.Srednia();
    student.CzyZaliczyl();

    cout<<endl;

    TpracownikFizyczny pracownikFizyczny;
    pracownikFizyczny.wczytaj_Fizyczny();
    pracownikFizyczny.wyswietl_Fizyczny();

    cout<<endl;

    TpracownikUmyslowy pracownikUmyslowy;
    pracownikUmyslowy.wczytaj_Umyslowy();
    pracownikUmyslowy.wyswietl_Umyslowy();

    return 0;
}
